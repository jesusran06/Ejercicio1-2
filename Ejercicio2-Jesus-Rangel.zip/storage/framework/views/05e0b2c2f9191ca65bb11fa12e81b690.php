<?php
use App\Models\User;

$users = User::all();
?>



<?php $__env->startSection('title', 'Lista de Usuarios'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <h1>Lista de Usuarios</h1>
    <a href="<?php echo e(route('users.create')); ?>" class="btn btn-primary">Nuevo Usuario</a>
</div>

<div class="table-responsive">
    <table class="table table-striped">
        <thead>
            <tr>
                <th>Avatar</th>
                <th>Nombre</th>
                <th>Edad</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td>
                    <img src="<?php echo e(asset('images/avatars/' . $user->avatar)); ?>" 
                         alt="<?php echo e($user->name); ?>" 
                         class="rounded-circle" 
                         style="width: 40px; height: 40px; object-fit: cover;">
                </td>
                <td><?php echo e($user->name); ?></td>
                <td><?php echo e($user->age); ?></td>
                <td>
                    <div class="btn-group gap-2">
                        <a href="<?php echo e(route('users.show', $user)); ?>" class="btn btn-info btn-sm">Ver</a>
                        <a href="<?php echo e(route('users.edit', $user)); ?>" class="btn btn-warning btn-sm">Editar</a>
                        <form action="<?php echo e(route('users.destroy', $user)); ?>" method="POST" class="d-inline">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('¿Estás seguro de eliminar este usuario?')">Eliminar</button>
                        </form>
                    </div>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\redSocial\resources\views/users/index.blade.php ENDPATH**/ ?>