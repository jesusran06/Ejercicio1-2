<?php $__env->startSection('title', 'Mi Perfil'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container mt-4">
        <div class="row">
            <div class="col-md-3">
                <div class="card">
                    <div class="card-body text-center">
                        <img src="<?php echo e(asset('images/avatars/' . $user->avatar)); ?>" alt="Avatar" class="rounded-circle" style="width: 150px; height: 150px; object-fit: cover;">
                        <h4 class="mt-3"><?php echo e($user->name); ?></h4>
                        <div class="mt-3">
                            <div class="mb-2">
                                <strong>Edad:</strong> <?php echo e($user->age); ?> años
                            </div>
                            <div class="mb-2">
                                <strong>Fecha de Registro:</strong> <?php echo e($user->created_at->format('d/m/Y')); ?>

                            </div>
                            <div class="mb-2">
                                <strong>Última Actualización:</strong> <?php echo e($user->updated_at->format('d/m/Y')); ?>

                            </div>
                            <div class="mb-2">
                                <strong>Avatar:</strong> <?php echo e($user->avatar); ?>

                            </div>
                        </div>
                        <a href="<?php echo e(route('users.edit', $user->id)); ?>" class="btn btn-primary w-100 mt-3">Editar Perfil</a>
                    </div>
                </div>
            </div>
            <div class="col-md-9">
                <div class="card mb-4">
                    <div class="card-body">
                        <h4 class="mb-4">Amigos</h4>
                        <?php if($friends->isEmpty()): ?>
                            <p class="text-muted">No tienes amigos aún.</p>
                        <?php else: ?>
                            <div class="row">
                                <?php $__currentLoopData = $friends; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $friend): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-md-4 mb-3">
                                        <div class="card">
                                            <div class="card-body text-center">
                                                <img src="<?php echo e(asset('images/avatars/' . $friend->avatar)); ?>" alt="<?php echo e($friend->name); ?>" class="rounded-circle" style="width: 100px; height: 100px; object-fit: cover;">
                                                <h5 class="mt-3"><?php echo e($friend->name); ?></h5>
                                                <p class="text-muted"><?php echo e($friend->age); ?> años</p>
                                                <form action="<?php echo e(route('users.removeFriend', ['user' => $user->id])); ?>" method="POST" class="d-inline">
                                                    <?php echo csrf_field(); ?>
                                                    <input type="hidden" name="friend_id" value="<?php echo e($friend->id); ?>">
                                                    <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('¿Estás seguro de que quieres eliminar a <?php echo e($friend->name); ?> de tus amigos?')">Eliminar Amigo</button>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="card">
                    <div class="card-body">
                        <h4 class="mb-4">Añadir Amigo</h4>
                        <?php if($potentialFriends->isEmpty()): ?>
                            <p class="text-muted">No hay usuarios disponibles para añadir como amigos.</p>
                        <?php else: ?>
                            <div class="row">
                                <?php $__currentLoopData = $potentialFriends; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $potentialFriend): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-md-4 mb-3">
                                        <div class="card">
                                            <div class="card-body text-center">
                                                <img src="<?php echo e(asset('images/avatars/' . $potentialFriend->avatar)); ?>" alt="<?php echo e($potentialFriend->name); ?>" class="rounded-circle" style="width: 100px; height: 100px; object-fit: cover;">
                                                <h5 class="mt-3"><?php echo e($potentialFriend->name); ?></h5>
                                                <p class="text-muted"><?php echo e($potentialFriend->age); ?> años</p>
                                                <form action="<?php echo e(route('users.addFriend', $user)); ?>" method="POST" class="d-inline">
                                                    <?php echo csrf_field(); ?>
                                                    <input type="hidden" name="friend_id" value="<?php echo e($potentialFriend->id); ?>">
                                                    <button type="submit" class="btn btn-primary btn-sm">Añadir Amigo</button>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\Redsocial\resources\views/users/profile.blade.php ENDPATH**/ ?>