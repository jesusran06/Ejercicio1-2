<?php
use App\Models\User;

$user = User::findOrFail($user->id);
?>



<?php $__env->startSection('title', $user->name); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-4">
        <div class="card">
            <div class="card-body text-center">
                <img src="<?php echo e(asset('images/avatars/' . $user->avatar)); ?>" 
                     alt="<?php echo e($user->name); ?>" 
                     class="rounded-circle" 
                     style="width: 150px; height: 150px; object-fit: cover;">
                <h3 class="mt-3"><?php echo e($user->name); ?></h3>
                <p class="text-muted">Edad: <?php echo e($user->age); ?></p>
            </div>
        </div>
    </div>

    <div class="col-md-8">
        <div class="card">
            <div class="card-header">Amigos</div>
            <div class="card-body">
                <div class="row">
                    <?php $__currentLoopData = $user->friends; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $friend): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-3 mb-3">
                        <div class="card">
                            <div class="card-body text-center">
                                <img src="<?php echo e(asset('images/avatars/' . $friend->avatar)); ?>" 
                                     alt="<?php echo e($friend->name); ?>" 
                                     class="rounded-circle" 
                                     style="width: 80px; height: 80px; object-fit: cover;">
                                <h6 class="mt-2"><?php echo e($friend->name); ?></h6>
                                <p class="text-muted"><?php echo e($friend->age); ?> años</p>
                                <form action="<?php echo e(route('users.removeFriend', $user)); ?>" method="POST" class="d-inline">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="friend_id" value="<?php echo e($friend->id); ?>">
                                    <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('¿Estás seguro de eliminar esta amistad?')">
                                        Eliminar Amistad
                                    </button>
                                </form>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <?php if($user->friends->isEmpty()): ?>
                        <p class="text-muted">Este usuario no tiene amigos aún.</p>
                    <?php endif; ?>

                    <div class="mt-4">
                        <h4>Añadir Amigo</h4>
                        <form action="<?php echo e(route('users.addFriend', $user)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="col-md-8">
                                    <select name="friend_id" class="form-select" required>
                                        <option value="">Selecciona un amigo...</option>
                                        <?php $__currentLoopData = User::where('id', '!=', $user->id)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $potentialFriend): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($potentialFriend->id); ?>" <?php echo e($user->isFriendWith($potentialFriend) ? 'disabled' : ''); ?>>
                                            <?php echo e($potentialFriend->name); ?> (<?php echo e($potentialFriend->age); ?> años)
                                        </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="col-md-4">
                                    <button type="submit" class="btn btn-primary w-100">Añadir Amigo</button>
                                </div>
                            </div>
                        </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\Redsocial\resources\views/users/show.blade.php ENDPATH**/ ?>