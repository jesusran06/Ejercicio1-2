# Red Social

Una red social simple desarrollada con Laravel y Bootstrap.

## Funcionalidades

- Gestión de usuarios (crear, editar, eliminar)
- Sistema de amistades
- Perfiles con avatar
- Interfaz moderna con Bootstrap

## Instalación

1. Clonar el repositorio
2. Copiar el archivo `.env.example` a `.env`
3. Configurar la base de datos en el archivo `.env`
4. Ejecutar `composer install`
5. Ejecutar `php artisan key:generate`
6. Ejecutar `php artisan migrate`
7. Ejecutar `php artisan serve`

## Requisitos

- PHP 8.0 o superior
- Composer
- Base de datos MySQL
- PHP CLI

## Tecnologías utilizadas

- Laravel 10
- Bootstrap 5
- PHP 8.0+

## Code of Conduct

In order to ensure that the Laravel community is welcoming to all, please review and abide by the [Code of Conduct](https://laravel.com/docs/contributions#code-of-conduct).

## Security Vulnerabilities

If you discover a security vulnerability within Laravel, please send an e-mail to Taylor Otwell via [taylor@laravel.com](mailto:taylor@laravel.com). All security vulnerabilities will be promptly addressed.

## License

The Laravel framework is open-sourced software licensed under the [MIT license](https://opensource.org/licenses/MIT).
