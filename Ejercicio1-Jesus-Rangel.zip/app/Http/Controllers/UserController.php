<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class UserController extends Controller
{
    public function index()
    {
        $users = User::all();
        return view('users.index', compact('users'));
    }

    public function create()
    {
        return view('users.create');
    }

    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'age' => 'required|integer|min:1',
            'password' => 'required|string|min:8',
            'avatar' => 'required|in:avatar1.png,avatar2.png,avatar3.png',
        ]);

        User::create([
            'name' => $request->name,
            'age' => $request->age,
            'password' => Hash::make($request->password),
            'avatar' => $request->avatar,
        ]);

        return redirect()->route('users.index')->with('success', 'Usuario creado exitosamente');
    }

    public function edit(User $user)
    {
        return view('users.edit', compact('user'));
    }

    public function update(Request $request, User $user)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'age' => 'required|integer|min:1',
            'password' => 'nullable|string|min:8',
            'avatar' => 'required|in:avatar1.png,avatar2.png,avatar3.png',
        ]);

        $user->update([
            'name' => $request->name,
            'age' => $request->age,
            'password' => $request->password ? Hash::make($request->password) : $user->password,
            'avatar' => $request->avatar,
        ]);

        return redirect()->route('users.index')->with('success', 'Usuario actualizado exitosamente');
    }

    public function destroy(User $user)
    {
        $user->delete();
        return redirect()->route('users.index')->with('success', 'Usuario eliminado exitosamente');
    }

    public function show(User $user)
    {
        return view('users.show', compact('user'));
    }

    public function addFriend(User $user, Request $request)
    {
        $friend = User::findOrFail($request->friend_id);
        $user->addFriend($friend);
        return redirect()->back()->with('success', 'Amistad creada exitosamente');
    }

    public function removeFriend(User $user, Request $request)
    {
        $friend = User::findOrFail($request->friend_id);
        $user->removeFriend($friend);
        return redirect()->back()->with('success', 'Amistad eliminada exitosamente');
    }
}
